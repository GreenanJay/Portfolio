import React, {Component} from 'react';
import axios from 'axios';
import Joke from "./Joke";
import './jokelist.css';
import uuid from 'uuid/v4';

const FetchJoke = 'https://icanhazdadjoke.com/';

class DadJokes extends Component {

    static defaultProps = {
        numJokesToGet: 10
    };

    constructor(props) {
        super(props);
        this.fetchJoke = this.fetchJoke.bind(this);
        this.newJoke = this.newJoke.bind(this);
        this.getNewJoke = this.genNewJoke.bind(this);
        this.state = {
            dadJokes: JSON.parse(window.localStorage.getItem("jokes") || '[]'),
            loading: false,
        };
        this.seenJokes = new Set(this.state.dadJokes.map(j => j.joke));
        console.log(this.seenJokes)
    }

    componentDidMount() {
        if(this.state.dadJokes.length === 0) {
            this.fetchJoke();
        }
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        this.seenJokes = new Set(this.state.dadJokes.map(j=> j.joke));
        window.localStorage.setItem('jokes', JSON.stringify(this.state.dadJokes));
    }

    async genNewJoke() {
        return (await axios.get("https://icanhazdadjoke.com/", {
            headers: {Accept: "application/json"}
        })).data;
    }

    async fetchJoke() {
        this.setState({loading: true});
        let jokes = [];
        while (jokes.length < this.props.numJokesToGet) {
            let res = await this.genNewJoke();
            if(!this.seenJokes.has(res.joke)) {
                jokes.push({joke: res.joke, id: res.id, votes: 0})
            } else {
                console.log("Caught!")
            }
        }

        this.setState({dadJokes: jokes, loading: false});
        window.localStorage.setItem('jokes', JSON.stringify(jokes));

    }

    async newJoke() {
        this.setState({loading: true});
        let res = await this.genNewJoke();
        if(!this.seenJokes.has(res.joke)) {
            this.setState(st => ({
                dadJokes: [...st.dadJokes, {joke: res.joke, id: res.id, votes: 0}],
                loading: false
            }))
        } else {
            console.log("Caught!");
            console.log(res.joke);
        }
    }

    handleVote = (vote, id) => {
          this.setState(st =>({
              dadJokes: st.dadJokes.map(j =>
                    j.id === id ? { ...j, votes: j.votes + vote}: j
              )
          }))
    };

    render() {
        // console.log(JSON.stringify(this.state.dadJokes));
        let jokes = this.state.dadJokes.sort((a, b) => b.votes - a.votes);
        let renderJokes = jokes.map(joke => <Joke key={joke.id} id={joke.id} votes={joke.votes} upvote={() => this.handleVote(1, joke.id)} downvote={() => this.handleVote(-1, joke.id)} joke={joke}/>);

        return (
            <div className='appjoke'>
            <div className={"JokeList"}>
                <div className="JokeList-sidebar">
                    <h2 className='JokeList-title'><span>Dad</span> Jokes</h2>
                    <img className={"JokeList-spinning"} src='https://assets.dryicons.com/uploads/icon/svg/8927/0eb14c71-38f2-433a-bfc8-23d9c99b3647.svg' />
                    <button className='JokeList-getmore' onClick={this.newJoke}>New Joke</button>
                </div>

                <div className={"JokeList-jokes"}>
                    {renderJokes}
                </div>

            </div>
            </div>
        );
    }
}

export default DadJokes;