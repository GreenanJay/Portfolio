import React, {Component} from 'react';

class LandingPage extends Component {
    render() {
        return (
            <div className={"LandingPage"}>
                <div className="jumbotron jumbotron-fluid">
                    <div className="container">
                        <h1 className="display-4">Adam Jay Greenan</h1>
                        <p className="lead">Welcome to my React.js portfolio.</p>
                    </div>
                </div>
            </div>
        );
    }
}

export default LandingPage;