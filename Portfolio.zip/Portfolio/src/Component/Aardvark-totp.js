//Author - Adam Jay Greenan
//Generate TOTP from given Secret: If it does not meet requirements, ammends secret safely.

import React, {Component} from 'react';
const totp = require('totp-generator');

class AardvarkTotp extends Component {
	
	state = {
		totp: null,
		elementTime: new Date().toLocaleTimeString(),
		secret: "123",
	};

	handleClick = () => {
		setInterval(this.updateTOTP, 1000);
	};

	handleChange = (e) => {
		let newSecret = e.target.value;
		this.setState(st => ({secret: newSecret}));
	};


	updateTOTP = () => {
		let secret = this.state.secret;
		//make string/secret compatible
		secret = this.updateString(secret);
		//Encrypt compatible secret via TOTP
		let passcode = totp(secret);
		//set the state: updaing TOTP and currTIME
		this.setState({totp: passcode, elementTime: new Date().toLocaleTimeString()})
	};

	updateString(str) {
		//Remove Spaces
		str.replace(/\s+/g, '');
		//While not divisble by 8: add 'A' to string
		while(str.length % 8 !== 0) {
			str = str + 'A';
		}
		return str;
	}
	
	render() {
		return (
			<div className={"Aardvark-totp"}>
				<span id={"totp"}>
					<h1>{this.state.totp}</h1>
				</span>
					<h2>{this.state.elementTime}</h2>
				<span id={"secret"}>
					<input onChange={this.handleChange} id={"secret-box"} type={"text"}/>
				</span>
				<button onClick={this.handleClick}>Start Generating</button>

				<p>This TOTP Generator uses a npm package called totp-generator. However when using Amazon we found the secret key given, does not meet the standards of the encryption, this simple yet effective script will adapt the secret key correctly before generating the key.</p>
				<p>This solution was not found anywhere online which makes this my first commercial experience.</p>
			</div>
		);
	}
}

export default AardvarkTotp;
