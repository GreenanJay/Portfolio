import React, {Component} from 'react';
import Todo from "./Todo";
import NewTodoForm from "./NewTodoForm";
import uuid from 'uuid/v4';
import './TodoList.css';
import './Todo.css';
import './NewTodoForm.css';

class TodoList extends Component {
    state = {
        todos: JSON.parse(window.localStorage.getItem("todos") || '[]'),
    };

    create = (todo) => {
        this.setState({todos: [...this.state.todos, todo]})
    };

    remove = (id) => {
        this.setState({todos: [...this.state.todos.filter(todo => todo.id !== id)]})
    };

    update = (id, updatedTodo) => {
        let Todos = this.state.todos.map(todo => {
            if(todo.id === id) {
                todo.task = updatedTodo
            }
            return todo;
        });
        this.setState({todos: Todos});
    };



    componentDidUpdate() {
        window.localStorage.setItem('todos', JSON.stringify(this.state.todos))
    }

    render() {
        let todos = this.state.todos.map(todo => <Todo task={todo.task} id={todo.id} key={todo.id} removeTodo={this.remove} updateTodo={this.update}/>);
        return (
            <div className={"TodoList"}>
                <h1>Todo List!</h1>
                <span>My React Todo list!</span>
                <ul>{todos}</ul>
                <NewTodoForm createTodo={this.create}/>
            </div>
        );
    }
}

export default TodoList;