import React, {Component} from 'react';
import uuid from 'uuid/v4';

class NewTodoForm extends Component {

    state = {
        task: ''
    };

    handleSubmit = (evt) => {
        evt.preventDefault();
        this.props.createTodo({...this.state, id: uuid()});
        this.setState({task: ''})
    };

    handleChange = (evt) => {
        this.setState({
            [evt.target.name]: evt.target.value
        })
    };

    render() {
        return (
            <div className={"NewTodoForm"}>
                <form onSubmit={this.handleSubmit}>
                    <input type="text" id="task" name="task" value={this.state.task} onChange={this.handleChange} placeholder='New todo!' />
                    <button>Add todo!</button>
                </form>
            </div>
        );
    }
}

export default NewTodoForm;