import React, {Component} from 'react';

class Todo extends Component {

    state = {
        isEditing: false,
        task: this.props.task
    };

    handleRemove = () => {
        this.props.removeTodo(this.props.id);
    };

    toggleEditing = () => {
        this.setState({isEditing: !this.state.isEditing})
    };

    handleChange = (evt) => {
        this.setState({[evt.target.name]: evt.target.value})
    };

    handleSubmit = (evt) => {
        evt.preventDefault();
        this.props.updateTodo(this.props.id, this.state.task);
        this.toggleEditing();
    };


    render() {
        let result;
        if(this.state.isEditing) {
            result =
            <form className={'Todo'} onSubmit={this.handleSubmit}>
                <input type="text" id="task" name="task" onChange={this.handleChange} value={this.state.task} />
                <button>Save</button>
            </form>
        } else {
            result =
            <div className={"Todo"}>
                <li className={'Todo-Task'}>{this.props.task}</li>
                <button onClick={this.toggleEditing}>Edit</button>
                <button onClick={this.handleRemove}>X</button>

            </div>
        }
        return result;
    }
}

export default Todo;