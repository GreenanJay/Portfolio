import React, {Component} from 'react';
import './game.css'
import Square from "./square";
import uuid from 'uuid/v4'
class Game extends Component {

    static defaultProps = {
        numOfSquares: 6
    };

    state = {
        color: '',
        squares: Array(this.props.numOfSquares)
    };

    componentDidMount() {
        let squares = [];
        let num = this.state.squares.length;
        for(let i = 0; i < num; i++) {
            squares.push({color: this.genRanColor(),
            id: uuid()})
        }
        console.log(squares);
        let color = squares[Math.floor(Math.random() * num)];
        this.setState({
            color: color,
            squares: squares
        })
    }

    handleClick = (color) => {
        if(color === this.state.color.color) {
            let squares = Array(6).fill({color: color});
            this.setState({squares: squares})
        } else {
            let squares = this.state.squares.filter(s => s.color !== color);
            this.setState({squares: squares})
        }
    };

    playAgain = () => {
        let squares = [];
        let num = this.state.squares.length;
        for(let i = 0; i < num; i++) {
            squares.push({color: this.genRanColor(),
                id: uuid()})
        }
        console.log(squares);
        let color = squares[Math.floor(Math.random() * num)];
        this.setState({
            color: color,
            squares: squares
        })
    };

    genRanColor = () => {
        let x = Math.floor(Math.random() * 255);
        let y = Math.floor(Math.random() * 255);
        let z = Math.floor(Math.random() * 255);
        return (`rgb(${x}, ${y}, ${z})`)
    };

    render() {
        return (
            <div className={"container-fluid game"}>
                <h1>The Great color picker game, done in React.js!</h1>
                <p>Click on the block with the color: <span className='Color'>{this.state.color.color}</span></p>
                {this.state.squares.map(square => <Square color={square.color} handleClick={this.handleClick} key={square.id}/>)}
                <button onClick={this.playAgain}>Play again!</button>
            </div>

        );
    }
}

export default Game;