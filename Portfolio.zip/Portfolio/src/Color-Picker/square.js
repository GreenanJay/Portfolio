import React, {Component} from 'react';

class Square extends Component {

    handleClick = () => {
        this.props.handleClick(this.props.color)
    };

    render() {
        return (
            <div onClick={this.handleClick} style={{backgroundColor: this.props.color}} className={"color"}>
            </div>
        );
    }
}

export default Square;