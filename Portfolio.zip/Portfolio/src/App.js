import React, {Component} from 'react';
import {Route, NavLink, Switch} from 'react-router-dom';
import LandingPage from "./Component/Landing-Page";
import DadJokes from "./Dad-Jokes/Dad-Jokes";
import AardvarkTotp from "./Component/Aardvark-totp";
import TodoList from "./Todo-List/TodoList";
import Game from './Color-Picker/game';

class App extends Component {
    render() {
        return (
            <div className={"App"}>
                <div className={'App-Nav'}>
                    <nav className="navbar navbar-expand-lg navbar-light bg-light">
                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav">
                                <li className="nav-item">
                                    <NavLink className={"nav-link"} exact activeClassName='active-link' to="/">Home</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className={"nav-link"} exact activeClassName='active-link' to="/dad-jokes">Dad Jokes Application!</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className={"nav-link"} exact activeClassName='active-link' to="/totp">TOTP</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className={"nav-link"} exact activeClassName='active-link' to="/todo">Todo-List!</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className={"nav-link"} exact activeClassName='active-link' to="/game">React Game</NavLink>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
                <Switch>
                    <Route exact path='/' component={LandingPage}/>
                    <Route exact path='/dad-jokes' component={DadJokes}/>
                    <Route exact path='/totp' component={AardvarkTotp}/>
                    <Route exact path='/todo' component={TodoList}/>
                    <Route exact path='/game' component={Game}/>
                </Switch>

            </div>
        );
    }
}

export default App;